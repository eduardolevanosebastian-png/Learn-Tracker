// ===== PLANIFICADOR =====
let planSemanal = JSON.parse(localStorage.getItem("planSemanal")) || [];
const listaPlan = document.getElementById("lista-plan");
document.getElementById("agregarPlan").addEventListener("click", ()=>{
    const dia = document.getElementById("diaPlan").value;
    const materia = document.getElementById("materiaPlan").value;
    const horas = Number(document.getElementById("horasPlan").value);
    if(!dia||!materia||horas<=0){ alert("Completa todos los datos del plan"); return;}
    planSemanal.push({dia,materia,horas}); localStorage.setItem("planSemanal",JSON.stringify(planSemanal)); mostrarPlan();
});
function mostrarPlan(){
    listaPlan.innerHTML="";
    planSemanal.forEach(plan=>{
        const li=document.createElement("li");
        const horasReales = calcularHorasDia(plan.dia);
        if(horasReales>=plan.horas) li.style.background="#4ade80"; else li.style.background="#fef08a";
        li.textContent=`${plan.dia} – ${plan.materia}: ${horasReales}/${plan.horas} h`;
        listaPlan.appendChild(li);
    });
}
function calcularHorasDia(dia){
    const avances = JSON.parse(localStorage.getItem("avances"))||[];
    return avances.filter(a=>new Date(a.fecha).toLocaleDateString("es-ES",{weekday:"long"})===dia).reduce((s,a)=>s+a.horas,0);
}

// ===== AVANCES =====
let avances = JSON.parse(localStorage.getItem("avances"))||[];
function registrarAvance(materia,horas,fecha){
    avances.push({materia,horas,fecha});
    localStorage.setItem("avances",JSON.stringify(avances));
    mostrarPlan(); mostrarGrafico(); generarCalendario(); verificarRetos(); verificarLogros();
}

// ===== GRAFICO =====
const contenedorGrafico=document.getElementById("contenedor-grafico");
function mostrarGrafico(){
    contenedorGrafico.innerHTML="";
    avances.forEach(a=>{
        const div=document.createElement("div");
        div.classList.add("barra"); div.style.height=(a.horas*15)+"px"; div.textContent=a.materia;
        contenedorGrafico.appendChild(div);
    });
}

// ===== CALENDARIO =====
const calendario=document.getElementById("calendario");
function generarCalendario(){
    calendario.innerHTML="";
    const hoy=new Date(), mes=hoy.getMonth(), año=hoy.getFullYear();
    const primerDia=new Date(año,mes,1).getDay(), diasMes=new Date(año,mes+1,0).getDate();
    for(let i=0;i<primerDia;i++){ const div=document.createElement("div"); calendario.appendChild(div);}
    for(let dia=1;dia<=diasMes;dia++){
        const fechaActual=`${año}-${String(mes+1).padStart(2,'0')}-${String(dia).padStart(2,'0')}`;
        const estudiado=avances.some(a=>a.fecha===fechaActual);
        const div=document.createElement("div"); div.classList.add("dia");
        if(estudiado) div.classList.add("estudiado");
        div.textContent=dia;
        calendario.appendChild(div);
    }
}

// ===== RETOS & LOGROS =====
let puntos = Number(localStorage.getItem("puntos"))||0;
const retos=[
    {id:1,texto:"Estudia 2 horas en un día",completado:false},
    {id:2,texto:"Estudia 5 horas en la semana",completado:false},
    {id:3,texto:"Registra 5 días de estudio",completado:false},
    {id:4,texto:"Alcanza 20 horas totales",completado:false}
];
const logros=JSON.parse(localStorage.getItem("logros"))||[
    {id:1,nombre:"📘 Primer paso",descripcion:"Registra tu primer estudio",desbloqueado:false},
    {id:2,nombre:"🔥 Constante",descripcion:"Estudia 3 días distintos",desbloqueado:false},
    {id:3,nombre:"⏱ 10 horas",descripcion:"Acumula 10 horas de estudio",desbloqueado:false},
    {id:4,nombre:"📅 7 días",descripcion:"Estudia 7 días distintos",desbloqueado:false},
    {id:5,nombre:"🏆 Disciplina",descripcion:"Alcanza 50 horas totales",desbloqueado:false}
];
const listaRetos=document.getElementById("lista-retos");
const contenedorLogros=document.getElementById("contenedor-logros");

function mostrarRetos(){
    listaRetos.innerHTML="";
    retos.forEach(r=>{
        const li=document.createElement("li");
        li.textContent=r.texto; if(r.completado) li.style.textDecoration="line-through";
        listaRetos.appendChild(li);
    });
    document.getElementById("puntos")?.textContent=puntos;
}

function verificarRetos(){
    const diasUnicos=new Set(avances.map(a=>a.fecha));
    if(avances.some(a=>a.horas>=2)) completarReto(1);
    if(avances.reduce((s,a)=>s+a.horas,0)>=5) completarReto(2);
    if(diasUnicos.size>=5) completarReto(3);
    if(avances.reduce((s,a)=>s+a.horas,0)>=20) completarReto(4);
}

function completarReto(id){
    const reto=retos.find(r=>r.id===id);
    if(reto&&!reto.completado){ reto.completado=true; puntos+=10; localStorage.setItem("puntos",puntos); mostrarRetos();}
}

function mostrarLogros(){
    contenedorLogros.innerHTML="";
    logros.forEach(l=>{
        const div=document.createElement("div"); div.textContent=`${l.nombre} - ${l.descripcion}`;
        if(l.desbloqueado) div.style.background="#4ade80";
        contenedorLogros.appendChild(div);
    });
    localStorage.setItem("logros",JSON.stringify(logros));
}

function verificarLogros(){
    if(avances.length>=1) desbloquearLogro(1);
    const dias=new Set(avances.map(a=>a.fecha));
    if(dias.size>=3) desbloquearLogro(2);
    if(avances.reduce((s,a)=>s+a.horas,0)>=10) desbloquearLogro(3);
    if(dias.size>=7) desbloquearLogro(4);
    if(avances.reduce((s,a)=>s+a.horas,0)>=50) desbloquearLogro(5);
}

function desbloquearLogro(id){
    const logro=logros.find(l=>l.id===id);
    if(logro&&!logro.desbloqueado){ logro.desbloqueado=true; mostrarLogros();}
}

// ===== INICIO =====
document.addEventListener("DOMContentLoaded",()=>{
    mostrarPlan(); mostrarGrafico(); generarCalendario(); mostrarRetos(); mostrarLogros(); verificarRetos(); verificarLogros();
});

