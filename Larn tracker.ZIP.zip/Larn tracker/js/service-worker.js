self.addEventListener("install", e => {
    console.log("Service Worker instalado");
});
self.addEventListener("activate", e => {
    console.log("Service Worker activo");
});
self.addEventListener("fetch", e => {
    // Puedes agregar cache aquí si quieres
});
