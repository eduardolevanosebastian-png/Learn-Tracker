# Learn-Tracker

Learn-Tracker es una web que ayuda a estudiantes a organizar tareas, proyectos, exposiciones y estudio. Incluye planificador, gráficos, calendario y retos gamificados.

## Cómo usar

1. Clona este repositorio.
2. Abre `index.html` en tu navegador.
3. Guarda cambios en `localStorage` para mantener tus datos.

## Funcionalidades

- Modo oscuro / claro
- Modo enfoque
- Planificador semanal
- Gráficos de progreso
- Retos y logros
- Calendario de estudio
